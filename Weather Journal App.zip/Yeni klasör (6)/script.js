var FirstName="Kubilay";
console.log(FirstName);

var SecondName="Özdemir";
console.log(SecondName);

var fullAge=true;
console.log(fullAge);

var job;
job="Doktor";
console.log(job);

var years="3";
console.log(years);

var fuction=23;